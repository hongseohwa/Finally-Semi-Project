package com.member.model;

public class MemberDTO {
	
	int member_num;
	int member_age;
	String member_name;
	String member_phone;
	String member_email;
	String member_addr1;
	String member_addr2;
	String member_addr3;
	String member_self;
	String member_nick;
	String member_gender;
	int member_animal1;
	int member_animal2;
	int member_animal3;
	String member_id;
	String member_pwd;
	
	public int getMember_num() {
		return member_num;
	}
	public void setMember_num(int member_num) {
		this.member_num = member_num;
	}
	public int getMember_age() {
		return member_age;
	}
	public void setMember_age(int member_age) {
		this.member_age = member_age;
	}
	public String getMember_name() {
		return member_name;
	}
	public void setMember_name(String member_name) {
		this.member_name = member_name;
	}
	public String getMember_phone() {
		return member_phone;
	}
	public void setMember_phone(String member_phone) {
		this.member_phone = member_phone;
	}
	public String getMember_email() {
		return member_email;
	}
	public void setMember_email(String member_email) {
		this.member_email = member_email;
	}
	public String getMember_addr1() {
		return member_addr1;
	}
	public void setMember_addr1(String member_addr1) {
		this.member_addr1 = member_addr1;
	}
	public String getMember_addr2() {
		return member_addr2;
	}
	public void setMember_addr2(String member_addr2) {
		this.member_addr2 = member_addr2;
	}
	public String getMember_addr3() {
		return member_addr3;
	}
	public void setMember_addr3(String member_addr3) {
		this.member_addr3 = member_addr3;
	}
	public String getMember_self() {
		return member_self;
	}
	public void setMember_self(String member_self) {
		this.member_self = member_self;
	}
	public String getMember_nick() {
		return member_nick;
	}
	public void setMember_nick(String member_nick) {
		this.member_nick = member_nick;
	}
	public String getMember_gender() {
		return member_gender;
	}
	public void setMember_gender(String member_gender) {
		this.member_gender = member_gender;
	}
	public int getMember_animal1() {
		return member_animal1;
	}
	public void setMember_animal1(int member_animal1) {
		this.member_animal1 = member_animal1;
	}
	public int getMember_animal2() {
		return member_animal2;
	}
	public void setMember_animal2(int member_animal2) {
		this.member_animal2 = member_animal2;
	}
	public int getMember_animal3() {
		return member_animal3;
	}
	public void setMember_animal3(int member_animal3) {
		this.member_animal3 = member_animal3;
	}
	public String getMember_id() {
		return member_id;
	}
	public void setMember_id(String member_id) {
		this.member_id = member_id;
	}
	public String getMember_pwd() {
		return member_pwd;
	}
	public void setMember_pwd(String member_pwd) {
		this.member_pwd = member_pwd;
	}
}
